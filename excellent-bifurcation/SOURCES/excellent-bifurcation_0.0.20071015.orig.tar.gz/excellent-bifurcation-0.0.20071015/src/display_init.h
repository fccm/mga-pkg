
void prepare_display(void);
//BITMAP *new_bitmap(int x, int y, const char errtxt []);
