int create_pbullet(int w, int type, int x, int y, int type2, int timeout);
void run_pbullets(void);
void init_pbullets(void);
void create_seeker(int w, int angle, int target);
void find_new_seeker_target(int w, int s);
void blue_beam_collision(void);
void blue2_beam_collision(void);

