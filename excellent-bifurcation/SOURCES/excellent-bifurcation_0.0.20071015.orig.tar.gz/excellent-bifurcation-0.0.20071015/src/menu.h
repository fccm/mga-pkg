
void startup_menu(void);
void loading_screen(void);
void loading_screen_wait(void);
