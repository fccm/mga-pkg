
void game_loop(void);
void new_game(void);
void player_hit(int side_hit);

