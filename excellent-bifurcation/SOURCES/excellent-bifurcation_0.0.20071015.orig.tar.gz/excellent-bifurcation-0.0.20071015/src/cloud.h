void init_clouds(void);
void run_clouds(void);
int create_cloud(int w, int type, int type2, int x, int y, int xs, int ys, int timer);
