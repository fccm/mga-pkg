void run_pickups(void);
void init_pickups(void);
//void destroy_pickup(int w, int p);
int create_pickup(int w, int colour, int x, int y);
void explode_pickup(int w, int p);
